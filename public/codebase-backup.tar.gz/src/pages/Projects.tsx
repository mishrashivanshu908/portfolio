import Background3D from "@/components/Background3D";
import { Button } from "@/components/ui/button";
import { api } from "@/convex/_generated/api";
import { useQuery } from "convex/react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { useNavigate } from "react-router";
import SEO from "@/components/SEO";

export default function Projects() {
  const navigate = useNavigate();
  const allProjects = useQuery(api.projects.getProjects, {});

  return (
    <div className="min-h-screen bg-background text-foreground font-mono selection:bg-primary selection:text-black">
      <SEO
        title="Blockchain Projects | Siddhu Singh (sidcodes) | Web3 Portfolio | DeFi & NFT Projects"
        description="Explore innovative blockchain projects by Siddhu Singh (sidcodes, Phantom Codes). DeFi protocols, NFT platforms, smart contracts, decentralized applications (dApps), Ethereum projects, and Web3 solutions. Full portfolio of blockchain development work."
        keywords={[
          "blockchain projects portfolio",
          "Web3 projects",
          "DeFi protocol examples",
          "NFT marketplace projects",
          "smart contract portfolio",
          "Ethereum dApp projects",
          "sidcodes projects",
          "Phantom Codes portfolio",
          "blockchain developer work"
        ]}
        section="Projects"
      />
      <Background3D />

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 p-6 flex justify-between items-start mix-blend-difference text-white pointer-events-none">
        <div className="flex flex-col pointer-events-auto">
          <Button 
            variant="ghost" 
            className="p-0 hover:bg-transparent hover:text-primary text-white transition-colors"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> BACK_TO_BASE
          </Button>
        </div>
        <div className="flex flex-col items-end text-right">
          <span className="text-xs font-bold tracking-widest opacity-50">ARCHIVE_STATUS</span>
          <span className="text-primary font-bold">UNLOCKED</span>
        </div>
      </header>

      <main className="pt-24 md:pt-32 px-6 pb-20">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12 md:mb-20"
          >
            <h1 className="text-4xl md:text-7xl font-black tracking-tighter mb-6">
              PROJECT_ARCHIVE
            </h1>
            <p className="text-muted-foreground max-w-xl text-base md:text-lg">
              Complete database of deployed protocols, experiments, and production systems.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 gap-8">
            {allProjects ? (
              allProjects.map((project, index) => (
                <motion.div
                  key={project._id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: index * 0.05 }}
                  className="group relative border border-white/10 bg-black/20 backdrop-blur-sm p-8 hover:border-primary/50 transition-all hover:bg-white/5"
                >
                  <div className="flex flex-col md:flex-row gap-8 justify-between">
                    <div className="space-y-4 flex-1">
                      <div className="flex items-center gap-4">
                        <span className="text-xs font-bold text-primary/50 border border-primary/20 px-2 py-1 rounded-full">
                          {project.category}
                        </span>
                        <span className="text-xs font-bold text-muted-foreground">
                          {project.year}
                        </span>
                      </div>
                      
                      <h3 className="text-3xl md:text-4xl font-bold tracking-tight group-hover:text-primary transition-colors flex items-center gap-3">
                        {project.title}
                        {project.isPhantomCode && (
                          <span className="text-xs border border-primary/50 text-primary px-2 py-0.5 rounded-full tracking-widest">
                            PHANTOM
                          </span>
                        )}
                      </h3>
                      
                      <p className="text-muted-foreground max-w-2xl leading-relaxed">
                        {project.description}
                      </p>

                      <div className="pt-4">
                        <span className="text-xs font-bold tracking-widest text-muted-foreground border-t border-white/10 pt-4 inline-block">
                          {project.tech}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start justify-end">
                      <Button 
                        variant="outline" 
                        className="rounded-none border-white/20 hover:bg-primary hover:text-black hover:border-primary transition-all group-hover:translate-x-2"
                        onClick={() => project.link && window.open(project.link, "_blank")}
                      >
                        VIEW_SOURCE <ArrowUpRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-center text-muted-foreground animate-pulse">
                LOADING_DATABASE...
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-bold tracking-widest text-muted-foreground">
          <div className="flex flex-col gap-2">
            <p>© 2025 SIDDHU SINGH // PHANTOM CODES</p>
            <p className="text-[10px] opacity-50 font-normal normal-case max-w-md">
              This project is part of PHANTOM CODES, my personal collection of apps designed to solve real problems—while creating new, more interesting problems to solve.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}