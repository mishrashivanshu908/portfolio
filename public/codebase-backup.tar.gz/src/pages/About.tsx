import Background3D from "@/components/Background3D";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Code2, Gamepad2, Car, Coffee } from "lucide-react";
import { useNavigate } from "react-router";
import SEO from "@/components/SEO";

export default function About() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground font-mono selection:bg-primary selection:text-black">
      <SEO
        title="About Siddhu Singh | Blockchain Developer | Web3 Architect | Phantom Codes Founder"
        description="Meet Siddhu Singh (sidcodes) - Professional blockchain developer and Web3 architect. Founder of Phantom Codes. Expert in Solidity, Ethereum, DeFi, smart contracts. Full-stack engineer specializing in decentralized applications. Mission to build the decentralized future."
        keywords={[
          "about Siddhu Singh",
          "sidcodes biography",
          "Phantom Codes founder",
          "blockchain developer bio",
          "Web3 architect about",
          "Siddhu Singh background",
          "blockchain consultant bio"
        ]}
        section="About"
      />
      <Background3D />

      <header className="fixed top-0 left-0 right-0 z-50 p-6 flex justify-between items-start mix-blend-difference text-white pointer-events-none">
        <div className="flex flex-col pointer-events-auto">
          <Button
            variant="ghost"
            className="p-0 hover:bg-transparent hover:text-primary text-white transition-colors"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> BACK_TO_BASE
          </Button>
        </div>
      </header>

      <main className="pt-24 md:pt-32 px-6 pb-20 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-12"
        >
          <div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-6">
              WHO_IS_THIS_GUY?
            </h1>
            <div className="space-y-4 text-lg md:text-xl text-muted-foreground leading-relaxed">
              <p>
                Hey there! 👋 I'm Siddhu Singh (aka <span className="text-primary font-bold">sidcodes</span>),
                just an <span className="text-primary">unemployed engineering student</span> who decided that
                playing with blockchain and Web3 is way more fun than attending lectures.
              </p>
              <p>
                Plot twist: I actually enjoy debugging at 3 AM. My IDE is basically my second home,
                and Claude is my best friend (sorry, Stack Overflow).
                Coffee-to-code ratio? Let's not talk about that.
              </p>
              <p>
                When I'm not pushing code to GitHub or breaking things on the blockchain, you'll find me
                obsessing over cars 🏎️ (because apparently one expensive hobby wasn't enough) or watching
                Batman edits at 3 AM. Don't judge—it's called "inspiration research."
              </p>
            </div>
          </div>

          {/* Fun Stats */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="border border-white/10 p-6 bg-gradient-to-br from-primary/10 to-transparent hover:border-primary/30 transition-all duration-300">
              <Code2 className="w-8 h-8 text-primary mb-3" />
              <h3 className="text-2xl font-bold mb-2">10000+</h3>
              <p className="text-sm text-muted-foreground">Lines of Code (mostly bugs), Obviously Vibe coding</p>
            </div>
            <div className="border border-white/10 p-6 bg-gradient-to-br from-primary/10 to-transparent hover:border-primary/30 transition-all duration-300">
              <Coffee className="w-8 h-8 text-primary mb-3" />
              <h3 className="text-2xl font-bold mb-2">∞</h3>
              <p className="text-sm text-muted-foreground">Cups of Coffee Consumed</p>
            </div>
            <div className="border border-white/10 p-6 bg-gradient-to-br from-primary/10 to-transparent hover:border-primary/30 transition-all duration-300">
              <Gamepad2 className="w-8 h-8 text-primary mb-3" />
              <h3 className="text-2xl font-bold mb-2">0</h3>
              <p className="text-sm text-muted-foreground">Hours of Sleep (who needs that?)</p>
            </div>
          </div>

          {/* What I'm About */}
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-primary">THE_MISSION</h2>
              <p className="text-muted-foreground">
                Build cool Web3 stuff, learn everything about blockchain, and maybe—just maybe—
                revolutionize the internet. No pressure. Also, graduate at some point.
              </p>
            </div>
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-primary">THE_DREAM</h2>
              <p className="text-muted-foreground">
                To code in a Batcave-like setup, drive a Batmobile (or at least a cool car),
                and build decentralized apps that would make even Alfred proud.
              </p>
            </div>
          </div>

          {/* Current Status */}
          <div className="border border-primary/30 p-8 bg-primary/5 backdrop-blur-sm">
            <h3 className="text-xl font-bold mb-4 text-primary">CURRENT_STATUS.exe</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="text-primary text-2xl">🎓</div>
                <div>
                  <h4 className="font-bold">Engineering Student</h4>
                  <p className="text-sm text-muted-foreground">
                    Current attendance this semester: <span className="text-primary font-bold">22%</span>.
                    Still figuring out which is more important: attending classes or building
                    the next big DeFi protocol. (Spoiler: it's the protocol)
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="text-primary text-2xl">💻</div>
                <div>
                  <h4 className="font-bold">Founder of Phantom Codes</h4>
                  <p className="text-sm text-muted-foreground">
                    Because "unemployed" sounds way cooler when you add "founder" to it.
                    Plus, I needed a fancy name for my GitHub repos.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="text-primary text-2xl">🏎️</div>
                <div>
                  <h4 className="font-bold">Car Enthusiast</h4>
                  <p className="text-sm text-muted-foreground">
                    I write code about decentralized finance while dreaming about centralized
                    engine blocks. The irony is not lost on me.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="text-primary text-2xl">🦇</div>
                <div>
                  <h4 className="font-bold">Code in the Shadows</h4>
                  <p className="text-sm text-muted-foreground">
                    My debugging philosophy: "It's not who I am underneath, but what I do that defines me."
                    Also applies to clean code. I work in the dark, so my code can shine in the light.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Tech Stack (but make it fun) */}
          <div className="border border-white/10 p-8 bg-black/20 backdrop-blur-sm">
            <h3 className="text-xl font-bold mb-4">TECH_I_PRETEND_TO_KNOW</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm text-primary font-bold mb-2">BLOCKCHAIN</h4>
                <p className="text-sm text-muted-foreground">
                  Solidity, Ethereum, Smart Contracts, DeFi, NFTs, Web3.js, Ethers.js
                  <br />
                  <span className="text-xs opacity-50">(I actually know these. Surprisingly.)</span>
                </p>
              </div>
              <div>
                <h4 className="text-sm text-primary font-bold mb-2">FULL_STACK</h4>
                <p className="text-sm text-muted-foreground">
                  React, TypeScript, Node.js, Next.js, Tailwind CSS
                  <br />
                  <span className="text-xs opacity-50">(The real reason I have no sleep schedule)</span>
                </p>
              </div>
            </div>
          </div>

          {/* The Real Talk */}
          <div className="border-t border-white/10 pt-8">
            <h3 className="text-2xl font-bold mb-4">THE_REAL_TALK</h3>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Look, I'm not claiming to be the next Satoshi Nakamoto or Tony Stark (though I'd settle
                for Bruce Wayne's bank account). I'm just a student who fell in love with blockchain
                technology and decided to build things instead of just reading about them.
              </p>
              <p>
                Sure, I'm unemployed. But I'm also building, learning, and creating things that might
                actually matter someday. Every project is a lesson, every bug is a teacher, and every
                3 AM debugging session is... well, it's probably caffeine poisoning, but let's call it dedication.
              </p>
              <p className="text-primary font-bold">
                TL;DR: Engineering student. Blockchain enthusiast. Car lover. Code in darkness, build in light.
                Builder of things. Breaker of things. Fixer of things. Repeat.
              </p>
            </div>
          </div>

          {/* Final Statement */}
          <div className="border border-primary/30 p-8 md:p-12 bg-gradient-to-br from-primary/10 to-transparent backdrop-blur-sm text-center">
            <div className="max-w-2xl mx-auto">
              <p className="text-base md:text-lg leading-relaxed">
                In the world where everyone wants to become Batman, I never wanted to because{" "}
                <span className="text-primary font-bold">I AM BATMAN.</span>
              </p>
            </div>
          </div>

          {/* Connect Section */}
          <div className="border-t border-white/10 pt-8 text-center">
            <h3 className="text-2xl font-bold mb-4">WANT_TO_COLLABORATE?</h3>
            <p className="text-muted-foreground mb-6">
              If you've read this far and still want to work with me, you're either brave or crazy.
              Either way, I like you already. Let's build something cool!
            </p>
            <Button
              onClick={() => navigate("/socials")}
              size="lg"
              className="font-bold tracking-widest group"
            >
              FIND_ME_ONLINE
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
