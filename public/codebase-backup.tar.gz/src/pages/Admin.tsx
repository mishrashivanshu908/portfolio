import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/convex/_generated/api";
import { useMutation, useQuery, useAction } from "convex/react";
import { Loader2, Plus, Trash2, LogOut, Pencil, X, Lock, Award, Link as LinkIcon } from "lucide-react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { Id } from "@/convex/_generated/dataModel";

export default function Admin() {
  const navigate = useNavigate();

  // Projects
  const projects = useQuery(api.projects.getProjects, {});
  const createProject = useMutation(api.projects.createProject);
  const updateProject = useMutation(api.projects.updateProject);
  const deleteProject = useMutation(api.projects.deleteProject);
  const seedProjects = useMutation(api.projects.seedProjects);

  // Certifications
  const certifications = useQuery(api.certifications.getCertifications, {});
  const createCertification = useMutation(api.certifications.createCertification);
  const updateCertification = useMutation(api.certifications.updateCertification);
  const deleteCertification = useMutation(api.certifications.deleteCertification);
  const seedCertifications = useMutation(api.certifications.seedCertifications);

  // Socials
  const socials = useQuery(api.socials.getSocials, {});
  const createSocial = useMutation(api.socials.createSocial);
  const updateSocial = useMutation(api.socials.updateSocial);
  const deleteSocial = useMutation(api.socials.deleteSocial);
  const seedSocials = useMutation(api.socials.seedSocials);

  const notifyVisitor = useAction(api.telegram.notifyVisitor);

  const [activeTab, setActiveTab] = useState<"projects" | "certifications" | "socials">("projects");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<Id<"projects"> | Id<"certifications"> | Id<"socials"> | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  
  const initialProjectFormState = {
    title: "",
    description: "",
    tech: "",
    category: "WEB3",
    year: new Date().getFullYear().toString(),
    link: "",
    featured: false,
    isPhantomCode: false,
  };

  const initialCertFormState = {
    title: "",
    issuer: "",
    date: "",
    credentialId: "",
    credentialUrl: "",
    skills: "",
    description: "",
    featured: false,
  };

  const initialSocialFormState = {
    platform: "",
    username: "",
    url: "",
    icon: "",
    description: "",
    featured: false,
    order: 0,
  };

  const [projectFormData, setProjectFormData] = useState(initialProjectFormState);
  const [certFormData, setCertFormData] = useState(initialCertFormState);
  const [socialFormData, setSocialFormData] = useState(initialSocialFormState);

  // Check session storage for existing session
  useEffect(() => {
    const savedPassword = sessionStorage.getItem("admin_password");
    if (savedPassword) {
      setPassword(savedPassword);
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "PF@sid31#") {
      setIsAuthenticated(true);
      setLoginError("");
      sessionStorage.setItem("admin_password", password);
      toast.success("Access Granted");
    } else {
      setLoginError("Access Denied: Invalid Credentials");
      toast.error("Invalid Password");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword("");
    sessionStorage.removeItem("admin_password");
    toast.info("Logged out");
  };

  // Project Handlers
  const handleProjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (editingId && activeTab === "projects") {
        await updateProject({
          id: editingId as Id<"projects">,
          ...projectFormData,
          link: projectFormData.link || undefined,
          year: projectFormData.year || undefined,
          tags: [],
          adminPassword: password,
        });
        toast.success("Project updated successfully");
        setEditingId(null);
      } else {
        await createProject({
          ...projectFormData,
          link: projectFormData.link || undefined,
          year: projectFormData.year || undefined,
          tags: [],
          adminPassword: password,
        });
        toast.success("Project created successfully");
      }
      setProjectFormData(initialProjectFormState);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to save project";
      toast.error(errorMessage);
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditProject = (project: any) => {
    setProjectFormData({
      title: project.title,
      description: project.description,
      tech: project.tech,
      category: project.category,
      year: project.year || "",
      link: project.link || "",
      featured: project.featured,
      isPhantomCode: project.isPhantomCode || false,
    });
    setEditingId(project._id);
    setActiveTab("projects");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteProject = async (id: Id<"projects">) => {
    if (!confirm("Are you sure you want to delete this project?")) return;
    try {
      await deleteProject({ id, adminPassword: password });
      toast.success("Project deleted");
      if (editingId === id) {
        handleCancelEdit();
      }
    } catch (error) {
      toast.error("Failed to delete project");
    }
  };

  // Certification Handlers
  const handleCertSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const skillsArray = certFormData.skills.split(",").map(s => s.trim()).filter(Boolean);

      if (editingId && activeTab === "certifications") {
        await updateCertification({
          id: editingId as Id<"certifications">,
          title: certFormData.title,
          issuer: certFormData.issuer,
          date: certFormData.date,
          credentialId: certFormData.credentialId || undefined,
          credentialUrl: certFormData.credentialUrl || undefined,
          skills: skillsArray,
          description: certFormData.description || undefined,
          featured: certFormData.featured,
          adminPassword: password,
        });
        toast.success("Certification updated successfully");
        setEditingId(null);
      } else {
        await createCertification({
          title: certFormData.title,
          issuer: certFormData.issuer,
          date: certFormData.date,
          credentialId: certFormData.credentialId || undefined,
          credentialUrl: certFormData.credentialUrl || undefined,
          skills: skillsArray,
          description: certFormData.description || undefined,
          featured: certFormData.featured,
          adminPassword: password,
        });
        toast.success("Certification created successfully");
      }
      setCertFormData(initialCertFormState);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to save certification";
      toast.error(errorMessage);
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditCert = (cert: any) => {
    setCertFormData({
      title: cert.title,
      issuer: cert.issuer,
      date: cert.date,
      credentialId: cert.credentialId || "",
      credentialUrl: cert.credentialUrl || "",
      skills: cert.skills.join(", "),
      description: cert.description || "",
      featured: cert.featured,
    });
    setEditingId(cert._id);
    setActiveTab("certifications");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteCert = async (id: Id<"certifications">) => {
    if (!confirm("Are you sure you want to delete this certification?")) return;
    try {
      await deleteCertification({ id, adminPassword: password });
      toast.success("Certification deleted");
      if (editingId === id) {
        handleCancelEdit();
      }
    } catch (error) {
      toast.error("Failed to delete certification");
    }
  };

  // Social Handlers
  const handleSocialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (editingId && activeTab === "socials") {
        await updateSocial({
          id: editingId as Id<"socials">,
          platform: socialFormData.platform,
          username: socialFormData.username,
          url: socialFormData.url,
          icon: socialFormData.icon || undefined,
          description: socialFormData.description || undefined,
          featured: socialFormData.featured,
          order: socialFormData.order,
          adminPassword: password,
        });
        toast.success("Social link updated successfully");
        setEditingId(null);
      } else {
        await createSocial({
          platform: socialFormData.platform,
          username: socialFormData.username,
          url: socialFormData.url,
          icon: socialFormData.icon || undefined,
          description: socialFormData.description || undefined,
          featured: socialFormData.featured,
          order: socialFormData.order,
          adminPassword: password,
        });
        toast.success("Social link created successfully");
      }
      setSocialFormData(initialSocialFormState);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to save social link";
      toast.error(errorMessage);
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditSocial = (social: any) => {
    setSocialFormData({
      platform: social.platform,
      username: social.username,
      url: social.url,
      icon: social.icon || "",
      description: social.description || "",
      featured: social.featured,
      order: social.order,
    });
    setEditingId(social._id);
    setActiveTab("socials");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDeleteSocial = async (id: Id<"socials">) => {
    if (!confirm("Are you sure you want to delete this social link?")) return;
    try {
      await deleteSocial({ id, adminPassword: password });
      toast.success("Social link deleted");
      if (editingId === id) {
        handleCancelEdit();
      }
    } catch (error) {
      toast.error("Failed to delete social link");
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setProjectFormData(initialProjectFormState);
    setCertFormData(initialCertFormState);
    setSocialFormData(initialSocialFormState);
  };

  const handleSeed = async () => {
    try {
      if (activeTab === "projects") {
        await seedProjects({ adminPassword: password });
        toast.success("Database seeded with initial projects");
      } else if (activeTab === "certifications") {
        await seedCertifications({ adminPassword: password });
        toast.success("Database seeded with initial certifications");
      } else {
        await seedSocials({ adminPassword: password });
        toast.success("Database seeded with initial social links");
      }
    } catch (error) {
      toast.error("Failed to seed database");
    }
  };

  const handleTestNotification = async () => {
    try {
      await notifyVisitor({ 
        path: "ADMIN_TEST_SIGNAL", 
        userAgent: "Manual Trigger from Admin Panel" 
      });
      toast.success("Signal sent to Telegram channel");
    } catch (error) {
      console.error(error);
      toast.error("Failed to send signal. Check server logs.");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white p-4 font-mono">
        <Card className="w-full max-w-md border-white/10 bg-white/5">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold tracking-widest text-primary">
              SECURE_ACCESS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="password">PASSPHRASE</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 bg-black/50 border-white/10"
                    placeholder="Enter admin password..."
                    autoFocus
                  />
                </div>
              </div>
              {loginError && (
                <p className="text-red-500 text-sm font-bold animate-pulse">{loginError}</p>
              )}
              <Button type="submit" className="w-full font-bold tracking-widest">
                AUTHENTICATE
              </Button>
              <Button 
                type="button" 
                variant="ghost" 
                className="w-full text-xs text-muted-foreground hover:text-white"
                onClick={() => navigate("/")}
              >
                ABORT_SEQUENCE
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8 font-mono">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">ADMIN_PANEL</h1>
          <div className="flex gap-4">
            <Button variant="outline" onClick={handleTestNotification}>Test Signal</Button>
            <Button variant="outline" onClick={handleSeed}>Seed DB</Button>
            <Button variant="destructive" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex gap-2 border-b border-white/10 pb-2">
          <Button
            variant={activeTab === "projects" ? "default" : "ghost"}
            onClick={() => setActiveTab("projects")}
            className="gap-2"
          >
            <Award className="h-4 w-4" /> Projects
          </Button>
          <Button
            variant={activeTab === "certifications" ? "default" : "ghost"}
            onClick={() => setActiveTab("certifications")}
            className="gap-2"
          >
            <Award className="h-4 w-4" /> Certifications
          </Button>
          <Button
            variant={activeTab === "socials" ? "default" : "ghost"}
            onClick={() => setActiveTab("socials")}
            className="gap-2"
          >
            <LinkIcon className="h-4 w-4" /> Socials
          </Button>
        </div>

        {activeTab === "projects" ? (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Create/Edit Project Form */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{editingId && activeTab === "projects" ? "EDIT_PROJECT" : "ADD_NEW_PROJECT"}</CardTitle>
                {editingId && activeTab === "projects" && (
                  <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                    <X className="mr-2 h-4 w-4" /> Cancel
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProjectSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={projectFormData.title}
                    onChange={e => setProjectFormData({...projectFormData, title: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    value={projectFormData.description}
                    onChange={e => setProjectFormData({...projectFormData, description: e.target.value})}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Tech Stack</Label>
                    <Input
                      value={projectFormData.tech}
                      onChange={e => setProjectFormData({...projectFormData, tech: e.target.value})}
                      placeholder="REACT / NODE"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input
                      value={projectFormData.category}
                      onChange={e => setProjectFormData({...projectFormData, category: e.target.value})}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Year</Label>
                    <Input
                      value={projectFormData.year}
                      onChange={e => setProjectFormData({...projectFormData, year: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Link</Label>
                    <Input
                      value={projectFormData.link}
                      onChange={e => setProjectFormData({...projectFormData, link: e.target.value})}
                      placeholder="https://..."
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={projectFormData.featured}
                    onCheckedChange={c => setProjectFormData({...projectFormData, featured: c})}
                  />
                  <Label>Featured Project</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={projectFormData.isPhantomCode}
                    onCheckedChange={c => setProjectFormData({...projectFormData, isPhantomCode: c})}
                  />
                  <Label>Part of Phantom Codes</Label>
                </div>
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : (editingId && activeTab === "projects" ? <Pencil className="mr-2" /> : <Plus className="mr-2" />)}
                  {editingId && activeTab === "projects" ? "Update Project" : "Create Project"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Project List */}
          <Card>
            <CardHeader>
              <CardTitle>EXISTING_PROJECTS ({projects?.length || 0})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                {projects?.map((project) => (
                  <div key={project._id} className={`flex items-start justify-between p-4 border rounded-lg transition-colors ${editingId === project._id ? "bg-primary/10 border-primary" : "bg-muted/20"}`}>
                    <div className="flex-1 mr-4">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold">{project.title}</h3>
                        {project.featured && <span className="text-xs bg-primary text-black px-1 rounded">FEATURED</span>}
                        {project.isPhantomCode && <span className="text-xs bg-white/20 text-white px-1 rounded">PHANTOM</span>}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{project.category} • {project.year}</p>
                      <p className="text-sm mt-2 line-clamp-2">{project.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleEditProject(project)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="icon"
                        onClick={() => handleDeleteProject(project._id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {!projects?.length && (
                  <div className="text-center text-muted-foreground py-8">
                    No projects found. Click "Seed DB" to populate.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          </div>
        ) : activeTab === "certifications" ? (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Create/Edit Certification Form */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{editingId && activeTab === "certifications" ? "EDIT_CERTIFICATION" : "ADD_NEW_CERTIFICATION"}</CardTitle>
                {editingId && activeTab === "certifications" && (
                  <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                    <X className="mr-2 h-4 w-4" /> Cancel
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCertSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input
                      value={certFormData.title}
                      onChange={e => setCertFormData({...certFormData, title: e.target.value})}
                      placeholder="AWS Certified Solutions Architect"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Issuer</Label>
                    <Input
                      value={certFormData.issuer}
                      onChange={e => setCertFormData({...certFormData, issuer: e.target.value})}
                      placeholder="Amazon Web Services"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Date (YYYY-MM)</Label>
                    <Input
                      value={certFormData.date}
                      onChange={e => setCertFormData({...certFormData, date: e.target.value})}
                      placeholder="2024-01"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Credential ID</Label>
                      <Input
                        value={certFormData.credentialId}
                        onChange={e => setCertFormData({...certFormData, credentialId: e.target.value})}
                        placeholder="AWS-SAA-2024"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Credential URL</Label>
                      <Input
                        value={certFormData.credentialUrl}
                        onChange={e => setCertFormData({...certFormData, credentialUrl: e.target.value})}
                        placeholder="https://..."
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Skills (comma-separated)</Label>
                    <Input
                      value={certFormData.skills}
                      onChange={e => setCertFormData({...certFormData, skills: e.target.value})}
                      placeholder="Cloud Architecture, AWS, Infrastructure"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      value={certFormData.description}
                      onChange={e => setCertFormData({...certFormData, description: e.target.value})}
                      placeholder="Optional description..."
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={certFormData.featured}
                      onCheckedChange={c => setCertFormData({...certFormData, featured: c})}
                    />
                    <Label>Featured Certification</Label>
                  </div>
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : (editingId && activeTab === "certifications" ? <Pencil className="mr-2" /> : <Plus className="mr-2" />)}
                    {editingId && activeTab === "certifications" ? "Update Certification" : "Create Certification"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Certifications List */}
            <Card>
              <CardHeader>
                <CardTitle>EXISTING_CERTIFICATIONS ({certifications?.length || 0})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                  {certifications?.map((cert) => (
                    <div key={cert._id} className={`flex items-start justify-between p-4 border rounded-lg transition-colors ${editingId === cert._id ? "bg-primary/10 border-primary" : "bg-muted/20"}`}>
                      <div className="flex-1 mr-4">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold">{cert.title}</h3>
                          {cert.featured && <span className="text-xs bg-primary text-black px-1 rounded">FEATURED</span>}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{cert.issuer} • {cert.date}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {cert.skills.slice(0, 3).map((skill) => (
                            <span key={skill} className="text-xs bg-white/10 px-2 py-0.5 rounded">{skill}</span>
                          ))}
                          {cert.skills.length > 3 && <span className="text-xs text-muted-foreground">+{cert.skills.length - 3}</span>}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleEditCert(cert)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="icon"
                          onClick={() => handleDeleteCert(cert._id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {!certifications?.length && (
                    <div className="text-center text-muted-foreground py-8">
                      No certifications found. Click "Seed DB" to populate.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : activeTab === "socials" ? (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Create/Edit Social Form */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{editingId && activeTab === "socials" ? "EDIT_SOCIAL" : "ADD_NEW_SOCIAL"}</CardTitle>
                {editingId && activeTab === "socials" && (
                  <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
                    <X className="mr-2 h-4 w-4" /> Cancel
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSocialSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Platform</Label>
                    <Input
                      value={socialFormData.platform}
                      onChange={e => setSocialFormData({...socialFormData, platform: e.target.value})}
                      placeholder="GitHub"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input
                      value={socialFormData.username}
                      onChange={e => setSocialFormData({...socialFormData, username: e.target.value})}
                      placeholder="@sidcodes"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>URL</Label>
                    <Input
                      value={socialFormData.url}
                      onChange={e => setSocialFormData({...socialFormData, url: e.target.value})}
                      placeholder="https://github.com/sidcodes"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Icon (Lucide Icon Name)</Label>
                      <Input
                        value={socialFormData.icon}
                        onChange={e => setSocialFormData({...socialFormData, icon: e.target.value})}
                        placeholder="Github"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Order</Label>
                      <Input
                        type="number"
                        value={socialFormData.order}
                        onChange={e => setSocialFormData({...socialFormData, order: parseInt(e.target.value) || 0})}
                        placeholder="1"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      value={socialFormData.description}
                      onChange={e => setSocialFormData({...socialFormData, description: e.target.value})}
                      placeholder="Optional description..."
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={socialFormData.featured}
                      onCheckedChange={c => setSocialFormData({...socialFormData, featured: c})}
                    />
                    <Label>Featured Social</Label>
                  </div>
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : (editingId && activeTab === "socials" ? <Pencil className="mr-2" /> : <Plus className="mr-2" />)}
                    {editingId && activeTab === "socials" ? "Update Social" : "Create Social"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Socials List */}
            <Card>
              <CardHeader>
                <CardTitle>EXISTING_SOCIALS ({socials?.length || 0})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                  {socials?.map((social: any) => (
                    <div key={social._id} className={`flex items-start justify-between p-4 border rounded-lg transition-colors ${editingId === social._id ? "bg-primary/10 border-primary" : "bg-muted/20"}`}>
                      <div className="flex-1 mr-4">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold">{social.platform}</h3>
                          {social.featured && <span className="text-xs bg-primary text-black px-1 rounded">FEATURED</span>}
                          <span className="text-xs text-muted-foreground">#{social.order}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{social.username}</p>
                        <a
                          href={social.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-primary hover:underline mt-1 inline-block"
                        >
                          {social.url}
                        </a>
                        {social.description && (
                          <p className="text-xs text-muted-foreground mt-2">{social.description}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleEditSocial(social)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="icon"
                          onClick={() => handleDeleteSocial(social._id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {!socials?.length && (
                    <div className="text-center text-muted-foreground py-8">
                      No social links found. Click "Seed DB" to populate.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}
      </div>
    </div>
  );
}