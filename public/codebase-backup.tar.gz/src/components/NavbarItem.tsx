import { useState } from "react";
import { LucideIcon } from "lucide-react";
import ScrambleText from "./ScrambleText";

interface NavbarItemProps {
  label: string;
  icon: LucideIcon;
  href: string;
}

export default function NavbarItem({ label, icon: Icon, href }: NavbarItemProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <a 
      href={href}
      className="group flex items-center gap-2 px-4 py-2.5 text-xs font-bold tracking-widest text-muted-foreground hover:text-primary hover:bg-white/5 transition-all rounded-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Icon className="w-4 h-4 group-hover:scale-110 transition-transform" />
      <span className="hidden md:inline-block">
        <ScrambleText text={label} shuffle={isHovered} />
      </span>
    </a>
  );
}