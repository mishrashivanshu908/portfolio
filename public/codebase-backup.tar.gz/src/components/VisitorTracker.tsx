import { api } from "@/convex/_generated/api";
import { useAction } from "convex/react";
import { useEffect } from "react";
import { useLocation } from "react-router";

export default function VisitorTracker() {
  const location = useLocation();
  const notifyVisitor = useAction(api.telegram.notifyVisitor);

  useEffect(() => {
    notifyVisitor({
      path: location.pathname,
      userAgent: navigator.userAgent,
    })
      .then(() => console.log("Visitor notification sent"))
      .catch((err) => console.error("Failed to notify visitor:", err));
  }, [notifyVisitor, location.pathname]);

  return null;
}