import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// Secure Admin Password
// In a production environment, this should be an environment variable
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "PF@sid31#";

function checkAdmin(password: string | undefined) {
  if (password !== ADMIN_PASSWORD) {
    throw new Error("Unauthorized: Invalid Admin Password");
  }
}

export const getProjects = query({
  args: { 
    category: v.optional(v.string()),
    featured: v.optional(v.boolean())
  },
  handler: async (ctx, args) => {
    let projects;
    
    if (args.category) {
      projects = await ctx.db
        .query("projects")
        .withIndex("by_category", (q) => q.eq("category", args.category!))
        .collect();
    } else {
      projects = await ctx.db.query("projects").collect();
    }

    if (args.featured !== undefined) {
      projects = projects.filter(p => p.featured === args.featured);
    }

    // Sort by year desc (if available) or creation time
    return projects.sort((a, b) => {
        if (a.year && b.year) return b.year.localeCompare(a.year);
        return b._creationTime - a._creationTime;
    });
  },
});

export const createProject = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    tech: v.string(),
    imageUrl: v.optional(v.string()),
    link: v.optional(v.string()),
    year: v.optional(v.string()),
    tags: v.array(v.string()),
    category: v.string(),
    featured: v.boolean(),
    isPhantomCode: v.optional(v.boolean()),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { adminPassword, ...projectData } = args;
    await ctx.db.insert("projects", projectData);
  },
});

export const updateProject = mutation({
  args: {
    id: v.id("projects"),
    title: v.string(),
    description: v.string(),
    tech: v.string(),
    imageUrl: v.optional(v.string()),
    link: v.optional(v.string()),
    year: v.optional(v.string()),
    tags: v.array(v.string()),
    category: v.string(),
    featured: v.boolean(),
    isPhantomCode: v.optional(v.boolean()),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { id, adminPassword, ...fields } = args;
    await ctx.db.patch(id, fields);
  },
});

export const deleteProject = mutation({
  args: { 
    id: v.id("projects"),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    await ctx.db.delete(args.id);
  },
});

// Seed function to populate initial data
export const seedProjects = mutation({
  args: {
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    
    const existing = await ctx.db.query("projects").take(1);
    if (existing.length > 0) return; // Already seeded

    const projects = [
      {
        title: "ROOMBRO",
        description: "Decentralized room booking protocol with on-chain settlement. Features automated dispute resolution and instant payments.",
        tech: "REACT / SOLIDITY / ETHEREUM",
        year: "2024",
        link: "#",
        category: "WEB3",
        tags: ["Blockchain", "React", "Solidity"],
        featured: true
      },
      {
        title: "COLLABHUB",
        description: "Real-time workspace synchronization engine. Supports conflict-free replicated data types (CRDTs) for seamless collaboration.",
        tech: "WEBRTC / NODE / REDIS",
        year: "2023",
        link: "#",
        category: "WEB2",
        tags: ["WebRTC", "Node.js", "Redis"],
        featured: true
      },
      {
        title: "AGGLAYER AI",
        description: "Neural network aggregation layer for blockchain data. Optimizes gas fees using predictive models.",
        tech: "PYTHON / TENSORFLOW / WEB3",
        year: "2024",
        link: "#",
        category: "AI/WEB3",
        tags: ["AI", "Python", "Web3"],
        featured: false
      },
      {
        title: "ARENA X",
        description: "High-frequency trading interface for NFT markets. Includes sniper tools and portfolio analytics.",
        tech: "RUST / WASM / REACT",
        year: "2023",
        link: "#",
        category: "WEB3",
        tags: ["Rust", "WASM", "DeFi"],
        featured: false
      },
      {
        title: "NEXUS VAULT",
        description: "Secure multi-sig wallet interface with social recovery modules.",
        tech: "NEXT.JS / ETHERS / TAILWIND",
        year: "2023",
        link: "#",
        category: "WEB3",
        tags: ["Security", "Wallet", "Next.js"],
        featured: false
      },
      {
        title: "SYNTH WAVE",
        description: "Browser-based audio synthesizer using WebAudio API and WebGL visualizations.",
        tech: "JAVASCRIPT / WEBGL / THREE.JS",
        year: "2022",
        link: "#",
        category: "CREATIVE",
        tags: ["Audio", "WebGL", "Creative"],
        featured: false
      }
    ];

    for (const p of projects) {
      await ctx.db.insert("projects", p);
    }
  },
});