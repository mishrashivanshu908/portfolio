"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";

export const notifyVisitor = action({
  args: {
    path: v.string(),
    userAgent: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // FORCE USE of provided credentials to bypass potentially incorrect Env Vars
    const botToken = "8566215477:AAGZd6HrrZZatHlQ_zyQFMnrsH5JNgwzevc";
    const chatId = "1786003945";

    if (!botToken || !chatId) {
      console.log("Telegram credentials not set.");
      return;
    }

    const message = `
🦇 *Master Wayne, sensors indicate a perimeter breach.*

📍 *Sector:* \`${args.path}\`
🕒 *Timestamp:* ${new Date().toLocaleString()}
🕵️ *Signature:* \`${args.userAgent || "Unknown"}\`

_Awaiting your command, sir._
    `.trim();

    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: "Markdown",
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Telegram API Error: ${response.status} - ${errorText}`);
      }
    } catch (error) {
      console.error("Failed to send Telegram notification:", error);
    }
  },
});