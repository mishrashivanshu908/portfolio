import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "PF@sid31#";

function checkAdmin(password: string | undefined) {
  if (password !== ADMIN_PASSWORD) {
    throw new Error("Unauthorized: Invalid Admin Password");
  }
}

export const getSocials = query({
  args: {
    featured: v.optional(v.boolean())
  },
  handler: async (ctx, args) => {
    let socials = await ctx.db
      .query("socials")
      .withIndex("by_order")
      .collect();

    if (args.featured !== undefined) {
      socials = socials.filter(s => s.featured === args.featured);
    }

    return socials;
  },
});

export const createSocial = mutation({
  args: {
    platform: v.string(),
    username: v.string(),
    url: v.string(),
    icon: v.optional(v.string()),
    description: v.optional(v.string()),
    featured: v.boolean(),
    order: v.number(),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { adminPassword, ...socialData } = args;
    await ctx.db.insert("socials", socialData);
  },
});

export const updateSocial = mutation({
  args: {
    id: v.id("socials"),
    platform: v.string(),
    username: v.string(),
    url: v.string(),
    icon: v.optional(v.string()),
    description: v.optional(v.string()),
    featured: v.boolean(),
    order: v.number(),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { id, adminPassword, ...fields } = args;
    await ctx.db.patch(id, fields);
  },
});

export const deleteSocial = mutation({
  args: {
    id: v.id("socials"),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    await ctx.db.delete(args.id);
  },
});

export const seedSocials = mutation({
  args: {
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);

    const existing = await ctx.db.query("socials").take(1);
    if (existing.length > 0) return;

    const socials = [
      {
        platform: "GitHub",
        username: "sidcodes",
        url: "https://github.com/sidcodes",
        icon: "Github",
        description: "Open source projects and code repositories",
        featured: true,
        order: 1
      },
      {
        platform: "LinkedIn",
        username: "siddhu-singh",
        url: "https://linkedin.com/in/siddhu-singh",
        icon: "Linkedin",
        description: "Professional network and experience",
        featured: true,
        order: 2
      },
      {
        platform: "X (Twitter)",
        username: "@sidcodes",
        url: "https://x.com/sidcodes",
        icon: "Twitter",
        description: "Tech insights and Web3 updates",
        featured: true,
        order: 3
      },
      {
        platform: "Medium",
        username: "@sidcodes",
        url: "https://medium.com/@sidcodes",
        icon: "BookOpen",
        description: "Technical articles and tutorials",
        featured: true,
        order: 4
      },
      {
        platform: "DoraHacks",
        username: "sidcodes",
        url: "https://dorahacks.io/user/sidcodes",
        icon: "Award",
        description: "Hackathon projects and achievements",
        featured: true,
        order: 5
      },
      {
        platform: "Dev.to",
        username: "sidcodes",
        url: "https://dev.to/sidcodes",
        icon: "Code2",
        description: "Developer community and posts",
        featured: false,
        order: 6
      },
      {
        platform: "Discord",
        username: "sidcodes#0000",
        url: "https://discord.com/users/sidcodes",
        icon: "MessageCircle",
        description: "Community discussions",
        featured: false,
        order: 7
      },
      {
        platform: "Telegram",
        username: "@sidcodes",
        url: "https://t.me/sidcodes",
        icon: "Send",
        description: "Direct messaging",
        featured: false,
        order: 8
      }
    ];

    for (const social of socials) {
      await ctx.db.insert("socials", social);
    }
  },
});
