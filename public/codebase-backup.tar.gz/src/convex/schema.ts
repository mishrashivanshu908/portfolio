import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove
    }).index("email", ["email"]), // index for the email. do not remove or modify

    projects: defineTable({
      title: v.string(),
      description: v.string(),
      tech: v.string(),
      imageUrl: v.optional(v.string()),
      link: v.optional(v.string()),
      year: v.optional(v.string()),
      tags: v.array(v.string()),
      category: v.string(),
      featured: v.boolean(),
      isPhantomCode: v.optional(v.boolean()),
    }).index("by_category", ["category"]),

    certifications: defineTable({
      title: v.string(),
      issuer: v.string(),
      date: v.string(),
      credentialId: v.optional(v.string()),
      credentialUrl: v.optional(v.string()),
      skills: v.array(v.string()),
      description: v.optional(v.string()),
      featured: v.boolean(),
    }).index("by_issuer", ["issuer"]),

    socials: defineTable({
      platform: v.string(),
      username: v.string(),
      url: v.string(),
      icon: v.optional(v.string()),
      description: v.optional(v.string()),
      featured: v.boolean(),
      order: v.number(),
    }).index("by_order", ["order"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;