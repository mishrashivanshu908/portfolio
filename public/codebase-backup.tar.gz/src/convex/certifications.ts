import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "PF@sid31#";

function checkAdmin(password: string | undefined) {
  if (password !== ADMIN_PASSWORD) {
    throw new Error("Unauthorized: Invalid Admin Password");
  }
}

export const getCertifications = query({
  args: {
    issuer: v.optional(v.string()),
    featured: v.optional(v.boolean())
  },
  handler: async (ctx, args) => {
    let certifications;

    if (args.issuer) {
      certifications = await ctx.db
        .query("certifications")
        .withIndex("by_issuer", (q) => q.eq("issuer", args.issuer!))
        .collect();
    } else {
      certifications = await ctx.db.query("certifications").collect();
    }

    if (args.featured !== undefined) {
      certifications = certifications.filter(c => c.featured === args.featured);
    }

    return certifications.sort((a, b) => {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });
  },
});

export const createCertification = mutation({
  args: {
    title: v.string(),
    issuer: v.string(),
    date: v.string(),
    credentialId: v.optional(v.string()),
    credentialUrl: v.optional(v.string()),
    skills: v.array(v.string()),
    description: v.optional(v.string()),
    featured: v.boolean(),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { adminPassword, ...certData } = args;
    await ctx.db.insert("certifications", certData);
  },
});

export const updateCertification = mutation({
  args: {
    id: v.id("certifications"),
    title: v.string(),
    issuer: v.string(),
    date: v.string(),
    credentialId: v.optional(v.string()),
    credentialUrl: v.optional(v.string()),
    skills: v.array(v.string()),
    description: v.optional(v.string()),
    featured: v.boolean(),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    const { id, adminPassword, ...fields } = args;
    await ctx.db.patch(id, fields);
  },
});

export const deleteCertification = mutation({
  args: {
    id: v.id("certifications"),
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);
    await ctx.db.delete(args.id);
  },
});

export const seedCertifications = mutation({
  args: {
    adminPassword: v.string(),
  },
  handler: async (ctx, args) => {
    checkAdmin(args.adminPassword);

    const existing = await ctx.db.query("certifications").take(1);
    if (existing.length > 0) return;

    const certifications = [
      {
        title: "AWS Certified Solutions Architect",
        issuer: "Amazon Web Services",
        date: "2024-01",
        credentialId: "AWS-SAA-2024",
        credentialUrl: "https://aws.amazon.com/certification/",
        skills: ["Cloud Architecture", "AWS", "Infrastructure"],
        description: "Professional level certification demonstrating expertise in designing distributed systems on AWS.",
        featured: true
      },
      {
        title: "Ethereum Smart Contract Developer",
        issuer: "ConsenSys Academy",
        date: "2023-08",
        credentialId: "CONSENSYS-DEV-2023",
        credentialUrl: "https://consensys.net/academy/",
        skills: ["Solidity", "Ethereum", "Smart Contracts"],
        description: "Comprehensive training in Ethereum development and smart contract security.",
        featured: true
      },
      {
        title: "Certified Kubernetes Administrator",
        issuer: "Cloud Native Computing Foundation",
        date: "2023-05",
        credentialId: "CKA-2023",
        credentialUrl: "https://www.cncf.io/certification/cka/",
        skills: ["Kubernetes", "DevOps", "Container Orchestration"],
        description: "Hands-on certification for Kubernetes cluster administration.",
        featured: false
      }
    ];

    for (const cert of certifications) {
      await ctx.db.insert("certifications", cert);
    }
  },
});
